package com.campustid.campus_tid.models.dto;

import java.time.LocalDate;

public record CourseResponse(
		Long id,
		String title,
		String titulo,
		String description,
		String descripcion,
		Long categoryId,
		Long categoriaId,
		String categoryName,
		String categoriaNombre,
		LocalDate startDate,
		LocalDate endDate,
		Integer capacity,
		Integer max,
		Integer cuposMaximos,
		String duration,
		String duracion,
		String level,
		String nivel,
		Long instructorId,
		String instructor,
		Long enrolledCount,
		Long inscritos,
		String imageUrl,
		String imagen,
		boolean active
) {}
