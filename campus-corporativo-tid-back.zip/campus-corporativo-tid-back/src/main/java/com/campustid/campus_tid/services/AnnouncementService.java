package com.campustid.campus_tid.services;

import com.campustid.campus_tid.exception.NotFoundException;
import com.campustid.campus_tid.exception.UnauthorizedException;
import com.campustid.campus_tid.models.AnnouncementEntity;
import com.campustid.campus_tid.models.UserEntity;
import com.campustid.campus_tid.models.dto.AnnouncementResponse;
import com.campustid.campus_tid.models.dto.AnnouncementUpsertRequest;
import com.campustid.campus_tid.repositories.AnnouncementRepository;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AnnouncementService {

	private final AnnouncementRepository announcementRepository;
	private final UserService userService;

	public AnnouncementService(AnnouncementRepository announcementRepository, UserService userService) {
		this.announcementRepository = announcementRepository;
		this.userService = userService;
	}

	@Transactional
	public AnnouncementResponse create(AnnouncementUpsertRequest req) {
		assertCanCreate(req.requesterRole());
		var a = new AnnouncementEntity();
		apply(a, req);
		return toResponse(announcementRepository.save(a));
	}

	@Transactional(readOnly = true)
	public List<AnnouncementResponse> list() {
		return announcementRepository.findAll().stream().map(AnnouncementService::toResponse).toList();
	}

	@Transactional(readOnly = true)
	public AnnouncementResponse get(Long id) {
		return toResponse(findEntity(id));
	}

	@Transactional
	public AnnouncementResponse update(Long id, AnnouncementUpsertRequest req) {
		var a = findEntity(id);
		assertCanManage(a, req.requesterId(), req.requesterRole());
		apply(a, req);
		return toResponse(announcementRepository.save(a));
	}

	@Transactional
	public void delete(Long id, Long requesterId, String requesterRole) {
		var a = findEntity(id);
		assertCanManage(a, requesterId, requesterRole);
		announcementRepository.delete(a);
	}

	@Transactional(readOnly = true)
	public AnnouncementEntity findEntity(Long id) {
		return announcementRepository.findById(id).orElseThrow(() -> new NotFoundException("Anuncio no encontrado"));
	}

	private void apply(AnnouncementEntity a, AnnouncementUpsertRequest req) {
		a.setTitle(req.title());
		a.setContent(req.content());
		a.setDate(req.date());
		if (a.getAuthor() == null && req.authorId() != null) {
			a.setAuthor(userService.findEntity(req.authorId()));
		}
	}

	private static void assertCanManage(AnnouncementEntity a, Long requesterId, String requesterRole) {
		if ("ADMIN".equalsIgnoreCase(requesterRole) || "Admin".equalsIgnoreCase(requesterRole)) {
			return;
		}
		if (a.getAuthor() != null && requesterId != null && a.getAuthor().getId().equals(requesterId)) {
			return;
		}
		throw new UnauthorizedException("No tienes permiso para modificar este anuncio");
	}

	private static void assertCanCreate(String requesterRole) {
		if (
			"ADMIN".equalsIgnoreCase(requesterRole)
				|| "Admin".equalsIgnoreCase(requesterRole)
				|| "INSTRUCTOR".equalsIgnoreCase(requesterRole)
				|| "Instructor".equalsIgnoreCase(requesterRole)
				|| "TEACHER".equalsIgnoreCase(requesterRole)
				|| "PROFESSOR".equalsIgnoreCase(requesterRole)
		) {
			return;
		}
		throw new UnauthorizedException("Los estudiantes solo pueden visualizar anuncios");
	}

	public static AnnouncementResponse toResponse(AnnouncementEntity a) {
		UserEntity author = a.getAuthor();
		return new AnnouncementResponse(
			a.getId(),
			a.getTitle(),
			a.getContent(),
			a.getDate(),
			a.getCreatedAt(),
			author == null ? null : author.getId(),
			author == null ? "Campus TID" : fullName(author)
		);
	}

	private static String fullName(UserEntity user) {
		return (user.getFirstName() + " " + user.getLastName()).trim();
	}
}
