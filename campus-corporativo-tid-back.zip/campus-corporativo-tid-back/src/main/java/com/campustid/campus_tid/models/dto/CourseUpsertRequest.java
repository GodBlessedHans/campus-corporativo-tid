package com.campustid.campus_tid.models.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;

public record CourseUpsertRequest(
		@JsonAlias({ "titulo", "nombre" }) @NotBlank @Size(max = 180) String title,
		@JsonAlias({ "descripcion" }) @NotBlank @Size(max = 2000) String description,
		@JsonAlias({ "categoriaId", "categoria_id" }) @NotNull Long categoryId,
		@JsonAlias({ "instructorId", "instructor_id" }) Long instructorId,
		LocalDate startDate,
		LocalDate endDate,
		@JsonAlias({ "durationHours", "duracionHoras", "duracion", "duration" }) Integer durationHours,
		@JsonAlias({ "max", "cuposMaximos", "cupoMaximo", "capacidad" }) Integer capacity,
		Boolean active
) {}
