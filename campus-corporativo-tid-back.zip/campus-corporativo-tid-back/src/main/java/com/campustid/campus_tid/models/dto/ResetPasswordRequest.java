package com.campustid.campus_tid.models.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record ResetPasswordRequest(
	@NotBlank @Email @Size(max = 180) String email,
	@NotBlank @Size(min = 6, max = 72) String newPassword,
	@NotBlank @Size(min = 6, max = 72) String confirmNewPassword
) {}
