package com.campustid.campus_tid.services;

import com.campustid.campus_tid.exception.NotFoundException;
import com.campustid.campus_tid.models.CourseEntity;
import com.campustid.campus_tid.models.dto.CourseResponse;
import com.campustid.campus_tid.models.dto.CourseUpsertRequest;
import com.campustid.campus_tid.repositories.CourseRepository;
import com.campustid.campus_tid.repositories.EnrollmentRepository;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CourseService {

	private final CourseRepository courseRepository;
	private final CategoryService categoryService;
	private final EnrollmentRepository enrollmentRepository;
	private final UserService userService;

	public CourseService(
			CourseRepository courseRepository,
			CategoryService categoryService,
			EnrollmentRepository enrollmentRepository,
			UserService userService
	) {
		this.courseRepository = courseRepository;
		this.categoryService = categoryService;
		this.enrollmentRepository = enrollmentRepository;
		this.userService = userService;
	}

	@Transactional(readOnly = true)
	public List<CourseResponse> list(Long categoryId) {
		var courses = categoryId == null ? courseRepository.findAll() : courseRepository.findByCategoryId(categoryId);
		return courses.stream().map(this::toResponse).toList();
	}

	@Transactional(readOnly = true)
	public CourseResponse get(Long id) {
		return toResponse(findEntity(id));
	}

	@Transactional
	public CourseResponse create(CourseUpsertRequest req) {
		var c = new CourseEntity();
		apply(c, req);
		return toResponse(courseRepository.save(c));
	}

	@Transactional
	public CourseResponse update(Long id, CourseUpsertRequest req) {
		var c = findEntity(id);
		apply(c, req);
		return toResponse(courseRepository.save(c));
	}

	@Transactional
	public void delete(Long id) {
		if (!courseRepository.existsById(id)) {
			throw new NotFoundException("Curso no encontrado");
		}
		courseRepository.deleteById(id);
	}

	@Transactional(readOnly = true)
	public CourseEntity findEntity(Long id) {
		return courseRepository.findById(id).orElseThrow(() -> new NotFoundException("Curso no encontrado"));
	}

	private void apply(CourseEntity c, CourseUpsertRequest req) {
		c.setTitle(req.title());
		c.setDescription(req.description());
		c.setCategory(categoryService.findEntity(req.categoryId()));
		if (req.instructorId() != null) {
			c.setInstructor(userService.findEntity(req.instructorId()));
		}
		if (req.durationHours() != null && req.durationHours() > 0) {
			int days = (int) Math.ceil(req.durationHours() / 8.0);
			LocalDate startDate = LocalDate.now();
			c.setStartDate(startDate);
			c.setEndDate(startDate.plusDays(Math.max(days, 1) - 1L));
		} else {
			c.setStartDate(req.startDate());
			c.setEndDate(req.endDate());
		}
		c.setCapacity(req.capacity());
		if (req.active() != null) {
			c.setActive(req.active());
		}
	}

	public CourseResponse toResponse(CourseEntity c) {
		long enrolledCount = enrollmentRepository.countByCourseId(c.getId());
		String duration = buildDuration(c);
		Long instructorId = c.getInstructor() == null ? null : c.getInstructor().getId();
		String instructorName = c.getInstructor() == null
				? "Sin instructor asignado"
				: (c.getInstructor().getFirstName() + " " + c.getInstructor().getLastName()).trim();
		return new CourseResponse(
				c.getId(),
				c.getTitle(),
				c.getTitle(),
				c.getDescription(),
				c.getDescription(),
				c.getCategory().getId(),
				c.getCategory().getId(),
				c.getCategory().getName(),
				c.getCategory().getName(),
				c.getStartDate(),
				c.getEndDate(),
				c.getCapacity(),
				c.getCapacity(),
				c.getCapacity(),
				duration,
				duration,
				"Basico",
				"Basico",
				instructorId,
				instructorName,
				enrolledCount,
				enrolledCount,
				null,
				null,
				c.isActive()
		);
	}

	private String buildDuration(CourseEntity c) {
		if (c.getStartDate() == null || c.getEndDate() == null) {
			return "";
		}
		long days = ChronoUnit.DAYS.between(c.getStartDate(), c.getEndDate()) + 1;
		if (days <= 0) {
			return "";
		}
		long hours = days * 8;
		return hours + "h (" + days + " dias)";
	}
}
